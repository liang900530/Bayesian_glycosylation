function [w] = wHM(con,y)

x0=rand(1,4)./2-rand(1,4)./2;
fun=@(w) abs(sigmo1(con,[w(1);w(2);w(3);w(4)])-y);
%options = optimoptions('lsqnonlin','Display','iter');
[w] = lsqnonlin(fun,x0);
end

