function [FD] = ffFD(wA2,wC1,wC2,wE1,wE2,wB)
global conA2;
global FA2;

FD=fFD(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))),fcon(fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wE1,fcon(fFE2(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))),fcon(fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wE1)),wE2,fcon(fFB(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wB);

end