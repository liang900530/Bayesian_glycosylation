function [con] = fcon(a)
global conA2;
global Man
global Gal
global cons
con=[Man,Gal,a,ones(cons,1)];

end
