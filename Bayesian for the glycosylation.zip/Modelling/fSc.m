function [Sc] = fSc(wA2,wC1)
global conA2;
global FA2;
global PA2

Sc=PA2.*sigmo1(conA2,wA2).*sigmo1(fcon(fFC1(wA2)),wC1);

end