%sigmoid function

function [y] = sigmo1(con,w)

y=1./(1+exp(con*w.*(-1)));

end

