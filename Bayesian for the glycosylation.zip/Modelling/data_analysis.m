% Data from articel, analysis
% Liang Zhang   2019-04-09
%% read data
clear all
clc
cd '/Users/liangzhang/Documents/kth/research/Experiment/S19.01/modelling'
data=xlsread('data.xlsx','P1','D3:n52'); 
%data(31:34,:)=[];
CD=data(:,1);
PR=data(:,2);
CSPR=data(:,3);
Cglc=data(:,4);
Clac=data(:,5);
Camm=data(:,6);
CmAb=data(:,7);
mu=data(:,8);
qIgG=data(:,9);
qGlc=data(:,10);
input=data(:,1:10);
Gly=data(:,11);

% % Corelation analysis
% [coeff,score,latent] =pca(input);
%  
% Modelinput=score(:,1:2);
%%

global Man
global Gal
Man=xlsread('data.xlsx','P1','F3:F52');  %CSPR
Gal=xlsread('data.xlsx','P1','G3:G52');  %Glucose concentration
IgG=xlsread('data.xlsx','P1','l3:l52');  %IgG flux
%Man(31:34,:)=[];
%Gal(31:34,:)=[];
%IgG(31:34,:)=[];
con=[Man,Gal,IgG,ones(50,1)];

%% The glycans data from experiment
global FA2;
global PA2;
global PGly;
PGly=xlsread('data.xlsx','Model CD, Glc','B3:J52'); 
%PGly(31:34,:)=[];
PGly=PGly./100;
FGly=PGly.*IgG;
FA=FGly(:,1); Fb=FGly(:,2); Fc=FGly(:,3); Fd=FGly(:,4); %flux
Fe=FGly(:,5); Ff=FGly(:,6); Fg=FGly(:,7); Fh=FGly(:,8); Fun=FGly(:,9);
PA=PGly(:,1); Pb=PGly(:,2); Pc=PGly(:,3); Pd=PGly(:,4); %percentage
Pe=PGly(:,5); Pf=PGly(:,6); Pg=PGly(:,7); Ph=PGly(:,8); Pun=PGly(:,9);
FG=Fg+Fh; PG=Pg+Ph;
FA2=IgG-FA-Fun; PA2=1-PA-Pun;
data=[Man,Gal,FGly];
R=[Pc,Pb,Pe,Pd,Pf,PG,Ph].*100;

%% lsqnonlin for HM

%while s1>400
w=wHM(con,PA);
WHM=[w(1);w(2);w(3);w(4)];
yHM=sigmo1(con,WHM);
EHM=abs(PA-yHM)./PA.*100;
s1HM=sum(EHM)
s2HM=max(EHM)
%end

%% G for G2F and G1F
conG2F=[Man,Gal,FG,ones(50,1)];
PFh=Ph./PG;
w=wHM(conG2F,PFh);
WG=[w(1);w(2);w(3);w(4)];
%PG1F=xlsread('modeldata.xlsx','Validation','o52:o57');
yh=sigmo1(conG2F,WG); % predicted   the percentage of h in G
PPh=PG.*yh;  % predicted, percentage of h
Eh=abs(Ph-PPh)./Ph.*100;
Eah=abs(Ph-yh).*100;
s1h=sum(Eh)
s2h=max(Eh)
a=yh.*PG;

%% Parameter Identification
global conA2;
conA2=[Man,Gal,FA2,ones(50,1)];

% FC1=fFC1(wA2);
% FC2=fFC2(wA2,wC1,fcon(fFC1(wA2)));
% FB=fFB(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))));
% FE1=fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))));
% FE2=fFE2(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))),fcon(fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wE1);
% FF=fFF(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))),fcon(fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wE1,fcon(fFE2(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))),fcon(fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wE1)),wE2);
% FD=fFD(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))),fcon(fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wE1,fcon(fFE2(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))),fcon(fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wE1)),wE2,fcon(fFB(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wB);
% 
% FC2=ffFC2(wA2,wC1);
% FB=ffFB(wA2,wC1,wC2);
% FE1=ffFE1(wA2,wC1,wC2);
% FE2=ffFE2(wA2,wC1,wC2,wE1);
% FF=ffFF(wA2,wC1,wC2,wE1,wE2);
% FD=ffFD(wA2,wC1,wC2,wE1,wE2,wB);

% wA2=[0.5,0.5,0.5,0.5]'; wC1=[0.5,0.5,0.5,0.5]'; wC2=[0.5,0.5,0.5,0.5]'; wF=[0.5,0.5,0.5,0.5]'; 
% wE1=[0.5,0.5,0.5,0.5]'; wE2=[0.5,0.5,0.5,0.5]'; wB=[0.5,0.5,0.5,0.5]';wD=[0.5,0.5,0.5,0.5]';

% 
% conC1=fcon(fFC1(wA2));
% conC2=fcon(ffFC2(wA2,wC1));
% conB=fcon(ffFB(wA2,wC1,wC2));
% conE1=fcon(ffFE1(wA2,wC1,wC2));
% conE2=fcon(ffFE2(wA2,wC1,wC2,wE1));
% conF=fcon(ffFF(wA2,wC1,wC2,wE1,wE2));
% conD=fcon(ffFD(wA2,wC1,wC2,wE1,wE2,wB));
% 
% 

%FC1=FA2.*sigmo1(conA2,wA2);

%FC2=FA2.*sigmo1(conA2,wA2).*sigmo2(conC1,wC1);
%FB=FA2.*sigmo2(conA2,wA2)+FA2.*sigmo1(conA2,wA2).*sigmo2(conC1,wC1).*sigmo1(conC2,wC2);
%FE1=FA2.*sigmo1(conA2,wA2).*sigmo2(conC1,wC1).*sigmo2(conC2,wC2);
%FE2=FA2.*sigmo1(conA2,wA2).*sigmo2(conC1,wC1).*sigmo2(conC2,wC2).*sigmo2(conE1,wE1);
%FF=FA2.*sigmo1(conA2,wA2).*sigmo2(conC1,wC1).*sigmo2(conC2,wC2).*sigmo2(conE1,wE1).*sigmo2(conE2,wE2);
%FD=(FA2.*sigmo2(conA2,wA2)+FA2.*sigmo1(conA2,wA2).*sigmo2(conC1,wC1).*sigmo1(conC2,wC2)).*sigmo2(conB,wB)+(FA2.*sigmo1(conA2,wA2).*sigmo2(conC1,wC1).*sigmo2(conC2,wC2).*sigmo2(conE1,wE1).*sigmo1(conE2,wE2));


%conC1=[Man,Gal,FC1,ones(26,1)];
%conC2=[Man,Gal,FC2,ones(26,1)];
%conB=[Man,Gal,FB,ones(26,1)];
%conE1=[Man,Gal,FE1,ones(26,1)];
%conE2=[Man,Gal,FE2,ones(26,1)];
%conD=[Man,Gal,FD,ones(26,1)];
%conF=[Man,Gal,FF,ones(26,1)];

% Sc=PA2.*sigmo1(conA2,wA2).*sigmo1(fcon(fFC1(wA2)),wC1);
% Sb=(PA2.*sigmo2(conA2,wA2)+PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo1(fcon(ffFC2(wA2,wC1)),wC2)).*sigmo1(fcon(ffFB(wA2,wC1,wC2)),wB);
% Se=PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo2(fcon(ffFC2(wA2,wC1)),wC2).*sigmo1(fcon(ffFE1(wA2,wC1,wC2)),wE1);
% Sd=((PA2.*sigmo2(conA2,wA2)+PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo1(fcon(ffFC2(wA2,wC1)),wC2)).*sigmo2(fcon(ffFB(wA2,wC1,wC2)),wB)+PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo2(fcon(ffFC2(wA2,wC1)),wC2).*sigmo2(fcon(ffFE1(wA2,wC1,wC2)),wE1).*sigmo1(fcon(ffFE2(wA2,wC1,wC2,wE1)),wE2)).*sigmo1(fcon(ffFD(wA2,wC1,wC2,wE1,wE2,wB)),wD);
% Sf=PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo2(fcon(ffFC2(wA2,wC1)),wC2).*sigmo2(fcon(ffFE1(wA2,wC1,wC2)),wE1).*sigmo2(fcon(ffFE2(wA2,wC1,wC2,wE1)),wE2).*sigmo1(fcon(ffFF(wA2,wC1,wC2,wE1,wE2)),wF);
% SG=(((PA2.*sigmo2(conA2,wA2)+PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo1(fcon(ffFC2(wA2,wC1)),wC2)).*sigmo2(fcon(ffFB(wA2,wC1,wC2)),wB)+PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo2(fcon(ffFC2(wA2,wC1)),wC2).*sigmo2(fcon(ffFE1(wA2,wC1,wC2)),wE1).*sigmo1(fcon(ffFE2(wA2,wC1,wC2,wE1)),wE2)).*sigmo1(fcon(ffFD(wA2,wC1,wC2,wE1,wE2,wB)),wD))./sigmo1(fcon(ffFD(wA2,wC1,wC2,wE1,wE2,wB)),wD).*sigmo2(fcon(ffFD(wA2,wC1,wC2,wE1,wE2,wB)),wD)+(PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo2(fcon(ffFC2(wA2,wC1)),wC2).*sigmo2(fcon(ffFE1(wA2,wC1,wC2)),wE1).*sigmo2(fcon(ffFE2(wA2,wC1,wC2,wE1)),wE2).*sigmo1(fcon(ffFF(wA2,wC1,wC2,wE1,wE2)),wF))./sigmo1(fcon(ffFF(wA2,wC1,wC2,wE1,wE2)),wF).*sigmo2(fcon(ffFF(wA2,wC1,wC2,wE1,wE2)),wF);
w=ww;
aa=100;
for i=1:20
    global cons
    cons=50;
    Man=xlsread('data.xlsx','P1','F3:F52');
    Gal=xlsread('data.xlsx','P1','G3:G52');
    IgG=xlsread('data.xlsx','P1','l3:l52'); 
    %Man(31:34,:)=[];
    %Gal(31:34,:)=[];
    %IgG(31:34,:)=[];

    con=[Man,Gal,IgG,ones(50,1)];
    PGly=xlsread('data.xlsx','Model CD, Glc','B3:J52'); PGly=PGly./100;
    %PGly(31:34,:)=[];
    FGly=PGly.*IgG;
    FA=FGly(:,1); Fb=FGly(:,2); Fc=FGly(:,3); Fd=FGly(:,4);
    Fe=FGly(:,5); Ff=FGly(:,6); Fg=FGly(:,7); Fh=FGly(:,8); Fun=FGly(:,9);
    PA=PGly(:,1); Pb=PGly(:,2); Pc=PGly(:,3); Pd=PGly(:,4);
    Pe=PGly(:,5); Pf=PGly(:,6); Pg=PGly(:,7); Ph=PGly(:,8); Pun=PGly(:,9);
    FG=Fg+Fh; PG=Pg+Ph;
    FA2=IgG-FA-Fun; PA2=1-PA-Pun;
    data=[Man,Gal,FGly];
    R=[Pc,Pb,Pe,Pd,Pf,PG,Ph].*100;
    conA2=[Man,Gal,FA2,ones(50,1)];


    w=Optim(PGly)
    
%     Man=xlsread('modeldata.xlsx','Validation','c26:c31'); %mannose
%     Gal=xlsread('modeldata.xlsx','Validation','d26:d31'); %galactose
%     IgG=xlsread('modeldata.xlsx','Validation','f26:f31'); %IgG concentration 
%     con=[Man,Gal,IgG,ones(6,1)];
%     PGly=xlsread('modeldata.xlsx','Validation','i26:q31'); PGly=PGly./100;
%     FGly=PGly.*IgG;
%     FA=FGly(:,1); Fb=FGly(:,2); Fc=FGly(:,3); Fd=FGly(:,4);
%     Fe=FGly(:,5); Ff=FGly(:,6); Fg=FGly(:,7); Fh=FGly(:,8); Fun=FGly(:,9);
%     PA=PGly(:,1); Pb=PGly(:,2); Pc=PGly(:,3); Pd=PGly(:,4);
%     Pe=PGly(:,5); Pf=PGly(:,6); Pg=PGly(:,7); Ph=PGly(:,8); Pun=PGly(:,9);
%     FG=Fg+Fh; PG=Pg+Ph;
%     FA2=IgG-FA-Fun; PA2=1-PA-Pun;
%     data=[Man,Gal,FGly];
%     R=[Pc,Pb,Pe,Pd,Pf,PG,Ph].*100;
%     conA2=[Man,Gal,FA2,ones(6,1)];
%     cons=6;

%save('weighto.m','w');




%% Error
    
    
    wA2=w(1:4)'; wC1=w(5:8)'; wC2=w(9:12)'; wE1=w(13:16)'; wE2=w(17:20)'; wB=w(21:24)'; wD=w(25:28)'; wF=w(29:32)'; 

    Sc=fSc(wA2,wC1);
    Sb=fSb(wA2,wC1,wC2,wB);
    Se=fSe(wA2,wC1,wC2,wE1);
    Sd=fSd(wA2,wC1,wC2,wE1,wE2,wB,wD);
    Sf=fSf(wA2,wC1,wC2,wE1,wE2,wF);
    SG=fSG(wA2,wC1,wC2,wE1,wE2,wB,wD,wF);
    Sh=SG.*yh.*100;
    Sg=SG.*100-Sh;
    S=[Sc,Sb,Sd,Se,Sf,SG].*100;

%relative error
    Ec=abs(Sc-Pc)./Pc.*100;
    Eb=abs(Sb-Pb)./Pb.*100;
    Ee=abs(Se-Pe)./Pe.*100;
    Ed=abs(Sd-Pd)./Pd.*100;
    Ef=abs(Sf-Pf)./Pf.*100;
    EG=abs(SG-PG)./PG.*100;
    E=[Ec,Eb,Ed,Ee,Ef,EG];

%absolute error
    Eac=abs(Sc-Pc).*100;
    Eab=abs(Sb-Pb).*100;
    Eae=abs(Se-Pe).*100;
    Ead=abs(Sd-Pd).*100;
    Eaf=abs(Sf-Pf).*100;
    EaG=abs(SG-PG).*100;
    Ea=[Eac,Eab,Ead,Eae,Eaf,EaG];
    EEa=sum(sum(Ea))

    if EEa<aa
        aa=EEa;
        ww=w;
    end
end















