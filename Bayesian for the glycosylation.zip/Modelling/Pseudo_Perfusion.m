%Probabilistic graphic model for pseudo perfusion
%Liang Zhang  KTH 2019-03-18


clear all; clc;
%% The concentration of galactose, mannose, and galactose
global Man % the first input
global Gal % the second input

load('Sugar_PP')
Man=Sugar(1:20,1);%mannose
Gal=Sugar(1:20,2); %galactose
load('IgG_PP')
IgG=IgG(1:20,:); %cell specific IgG productivity
con=[Man,Gal,IgG,ones(20,1)]; % the culture condition


%% The glycans data from experiment
global FA2; %the flux of IgG except high mannose
global PA2; %the precetage of all glycans except high mannose
global PGly;
load('PGly_PP')
PGly=PGly(1:20,:);
FGly=PGly.*IgG;
FA=FGly(:,1); Fb=FGly(:,2); Fc=FGly(:,3); Fd=FGly(:,4);
Fe=FGly(:,5); Ff=FGly(:,6); Fg=FGly(:,7); Fh=FGly(:,8); Fun=FGly(:,9);
PA=PGly(:,1); Pb=PGly(:,2); Pc=PGly(:,3); Pd=PGly(:,4);
Pe=PGly(:,5); Pf=PGly(:,6); Pg=PGly(:,7); Ph=PGly(:,8); Pun=PGly(:,9);
FG=Fg+Fh; PG=Pg+Ph;
FA2=IgG-FA-Fun; PA2=1-PA-Pun;
data=[Man,Gal,FGly];
R=[Pc,Pb,Pe,Pd,Pf,PG,Ph].*100;

%% lsqnonlin for HM

w=wHM(con,PA);
WHM=[w(1);w(2);w(3);w(4)];
yHM=sigmo1(con,WHM);
EHM=abs(PA-yHM)./PA.*100;
s1HM=sum(EHM)
s2HM=max(EHM)

%% GA for G2F and G1F
conG2F=[Man,Gal,FG,ones(20,1)];
PFh=Ph./PG;
w=wHM(conG2F,PFh);
WG=[w(1);w(2);w(3);w(4)];
yh=sigmo1(conG2F,WG);
Ph=PG.*yh;
Pg=PG-Ph;

%% Parameter Identification
global conA2;
conA2=[Man,Gal,FA2,ones(20,1)];
global cons
cons=20;

w=Optim(PGly)

%% Validation

load('Sugar_PP')
Man=Sugar(21:26,1);
Gal=Sugar(21:26,2); 
load('IgG_PP')
IgG=IgG(21:26,:); %cell specific IgG productivity
con=[Man,Gal,IgG,ones(6,1)];
load('PGly_PP')
PGly=PGly(21:26,:);

FGly=PGly.*IgG;
FA=FGly(:,1); Fb=FGly(:,2); Fc=FGly(:,3); Fd=FGly(:,4);
Fe=FGly(:,5); Ff=FGly(:,6); Fg=FGly(:,7); Fh=FGly(:,8); Fun=FGly(:,9);
PA=PGly(:,1); Pb=PGly(:,2); Pc=PGly(:,3); Pd=PGly(:,4);
Pe=PGly(:,5); Pf=PGly(:,6); Pg=PGly(:,7); Ph=PGly(:,8); Pun=PGly(:,9);
FG=Fg+Fh; PG=Pg+Ph;
FA2=IgG-FA-Fun; PA2=1-PA-Pun;
data=[Man,Gal,FGly];
R=[Pc,Pb,Pe,Pd,Pf,PG,Ph].*100;
conA2=[Man,Gal,FA2,ones(6,1)];
cons=6;

wA2=w(1:4)'; wC1=w(5:8)'; wC2=w(9:12)'; wE1=w(13:16)'; wE2=w(17:20)'; wB=w(21:24)'; wD=w(25:28)'; wF=w(29:32)'; 

Sc=fSc(wA2,wC1);
Sb=fSb(wA2,wC1,wC2,wB);
Se=fSe(wA2,wC1,wC2,wE1);
Sd=fSd(wA2,wC1,wC2,wE1,wE2,wB,wD);
Sf=fSf(wA2,wC1,wC2,wE1,wE2,wF);
SG=fSG(wA2,wC1,wC2,wE1,wE2,wB,wD,wF);
S=[Sc,Sb,Sd,Se,Sf,SG].*100;

%absolute error
Eac=abs(Sc-Pc).*100;
Eab=abs(Sb-Pb).*100;
Eae=abs(Se-Pe).*100;
Ead=abs(Sd-Pd).*100;
Eaf=abs(Sf-Pf).*100;
EaG=abs(SG-PG).*100;
Ea=[Eac,Eab,Ead,Eae,Eaf,EaG];
EEa=sum(sum(Ea));

conG2F=[Man,Gal,FG,ones(6,1)];
PFh=Ph./PG;
yh=sigmo1(conG2F,WG);
PPh=SG.*yh;
PPg=SG-PPh;
Eah=abs(PPh-Ph).*100;

%The predicted G0F, G1F and G2F of the validation set
G0F=S(:,3);
G1F=PPg*100;
G2F=PPh*100;

% The experimental data of G0F, G1F and G2F of the validation set
RG0F=Pd*100;
RG1F=Pg*100;
RG2F=Ph*100;




