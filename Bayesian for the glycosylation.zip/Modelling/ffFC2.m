function [FC2] = ffFC2(wA2,wC1)
global conA2;
global FA2;

FC2=fFC2(wA2,wC1,fcon(fFC1(wA2)));

end
