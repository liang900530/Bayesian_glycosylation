function [FF] = ffFF(wA2,wC1,wC2,wE1,wE2)
global conA2;
global FA2;

FF=fFF(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))),fcon(fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wE1,fcon(fFE2(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))),fcon(fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))))),wE1)),wE2);

end