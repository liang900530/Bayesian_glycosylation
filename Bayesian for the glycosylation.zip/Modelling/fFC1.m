function [FC1] = fFC1(wA2)
global conA2;
global FA2;

FC1=FA2.*sigmo1(conA2,wA2);

end

