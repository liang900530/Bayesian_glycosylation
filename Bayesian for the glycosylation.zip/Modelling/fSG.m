function [SG] = fSG(wA2,wC1,wC2,wE1,wE2,wB,wD,wF)
global conA2;
global FA2;
global PA2

SG=(((PA2.*sigmo2(conA2,wA2)+PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo1(fcon(ffFC2(wA2,wC1)),wC2)).*sigmo2(fcon(ffFB(wA2,wC1,wC2)),wB)+PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo2(fcon(ffFC2(wA2,wC1)),wC2).*sigmo2(fcon(ffFE1(wA2,wC1,wC2)),wE1).*sigmo1(fcon(ffFE2(wA2,wC1,wC2,wE1)),wE2)).*sigmo1(fcon(ffFD(wA2,wC1,wC2,wE1,wE2,wB)),wD))./sigmo1(fcon(ffFD(wA2,wC1,wC2,wE1,wE2,wB)),wD).*sigmo2(fcon(ffFD(wA2,wC1,wC2,wE1,wE2,wB)),wD)+(PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo2(fcon(ffFC2(wA2,wC1)),wC2).*sigmo2(fcon(ffFE1(wA2,wC1,wC2)),wE1).*sigmo2(fcon(ffFE2(wA2,wC1,wC2,wE1)),wE2).*sigmo1(fcon(ffFF(wA2,wC1,wC2,wE1,wE2)),wF))./sigmo1(fcon(ffFF(wA2,wC1,wC2,wE1,wE2)),wF).*sigmo2(fcon(ffFF(wA2,wC1,wC2,wE1,wE2)),wF);

end