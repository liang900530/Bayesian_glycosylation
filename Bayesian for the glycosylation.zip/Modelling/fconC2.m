function [conC2] = fconC2(a)
global conA2;

conC2=[Man,Gal,a,ones(26,1)];

end
