% Probabilistic grahic model for Fed batch culture, Validation for duplicate 1
% Liang Zhang KTH  2019-04-09
%% read data
clear all
clc
load('input_FB');
[coeff,score,latent] =pca(input);
score(17:24,:)=[];score(1:8,:)=[];

global Man % the first input
global Gal % the second input
Man=score(:,1);
Gal=score(:,2);

load('IgG_FB');
IgG(17:24,:)=[];IgG(1:8,:)=[];

con=[Man,Gal,IgG,ones(16,1)]; %the culture condition

%% The glycans data from experiment
global FA2;
global PA2;
global PGly;
load('PGly_FB');
PGly(17:24,:)=[];PGly(1:8,:)=[];

PGly=PGly./100;
FGly=PGly.*IgG;
FA=FGly(:,1); Fb=FGly(:,2); Fc=FGly(:,3); Fd=FGly(:,4); %flux
Fe=FGly(:,5); Ff=FGly(:,6); Fg=FGly(:,7); Fh=FGly(:,8); Fun=FGly(:,9);
PA=PGly(:,1); Pb=PGly(:,2); Pc=PGly(:,3); Pd=PGly(:,4); %percentage
Pe=PGly(:,5); Pf=PGly(:,6); Pg=PGly(:,7); Ph=PGly(:,8); Pun=PGly(:,9);
FG=Fg+Fh; PG=Pg+Ph;
FA2=IgG-FA-Fun; PA2=1-PA-Pun;
data=[Man,Gal,FGly];
R=[Pc,Pb,Pe,Pd,Pf,PG,Ph].*100;

%% lsqnonlin for HM

w=wHM(con,PA);
WHM=[w(1);w(2);w(3);w(4)]
yHM=sigmo1(con,WHM)

%% G for G2F and G1F
conG2F=[Man,Gal,FG,ones(16,1)];
PFh=Ph./PG;
w=wHM(conG2F,PFh);
WG=[w(1);w(2);w(3);w(4)];
yh=sigmo1(conG2F,WG); % predicted   the percentage of h in G
PPh=PG.*yh;  % predicted, percentage of h
Eh=abs(Ph-PPh)./Ph.*100;
Eah=abs(Ph-PPh).*100;
s1h=sum(Eh)
s2h=max(Eh)
a=yh.*PG;

%% Parameter Identification
global conA2;
conA2=[Man,Gal,FA2,ones(16,1)];

global cons
cons=16;

w=OptimFB(PGly)
    
%% validation Error
    
wA2=w(1:4)'; wC1=w(5:8)'; wC2=w(9:12)'; wE1=w(13:16)'; wE2=w(17:20)'; wB=w(21:24)'; wD=w(25:28)'; wF=w(29:32)'; 

load('input_FB');
[coeff,score,latent] =pca(input);
score(25:32,:)=[];score(9:16,:)=[];

Man=score(:,1);
Gal=score(:,2);

load('IgG_FB');
IgG(25:32,:)=[];IgG(9:16,:)=[];

con=[Man,Gal,IgG,ones(16,1)];

load('PGly_FB');
PGly(25:32,:)=[];PGly(9:16,:)=[];

PGly=PGly./100;
FGly=PGly.*IgG;
FA=FGly(:,1); Fb=FGly(:,2); Fc=FGly(:,3); Fd=FGly(:,4); %flux
Fe=FGly(:,5); Ff=FGly(:,6); Fg=FGly(:,7); Fh=FGly(:,8); Fun=FGly(:,9);
PA=PGly(:,1); Pb=PGly(:,2); Pc=PGly(:,3); Pd=PGly(:,4); %percentage
Pe=PGly(:,5); Pf=PGly(:,6); Pg=PGly(:,7); Ph=PGly(:,8); Pun=PGly(:,9);
FG=Fg+Fh; PG=Pg+Ph;
FA2=IgG-FA-Fun; PA2=1-PA-Pun;
data=[Man,Gal,FGly];
R=[Pc,Pb,Pe,Pd,Pf,PG,Ph].*100;

Sc=fSc(wA2,wC1);
Sb=fSb(wA2,wC1,wC2,wB);
Se=fSe(wA2,wC1,wC2,wE1);
Sd=fSd(wA2,wC1,wC2,wE1,wE2,wB,wD);
Sf=fSf(wA2,wC1,wC2,wE1,wE2,wF);
SG=fSG(wA2,wC1,wC2,wE1,wE2,wB,wD,wF);
Sh=SG.*yh.*100;
Sg=SG.*100-Sh;
S=[Sc,Sb,Sd,Se,Sf,SG].*100;

%absolute error
Eac=abs(Sc-Pc).*100;
Eab=abs(Sb-Pb).*100;
Eae=abs(Se-Pe).*100;
Ead=abs(Sd-Pd).*100;
Eaf=abs(Sf-Pf).*100;
EaG=abs(SG-PG).*100;
Ea=[Eac,Eab,Ead,Eae,Eaf,EaG];
EEa=sum(sum(Ea))

conG2F=[Man,Gal,FG,ones(16,1)];
yh=sigmo1(conG2F,WG); % predicted   the percentage of h in G
PPh=SG.*yh*100;  % predicted, percentage of h
PPg=SG*100-PPh;
Eh=abs(Ph-PPh)./Ph.*100;
Eah=abs(Ph-PPh).*100;
s1h=sum(Eh)
s2h=max(Eh)
a=yh.*SG;

%The predicted G0F, G1F and G2F of the validation set
G0F=S(:,3);
G1F=PPg;
G2F=PPh;

% The experimental data of G0F, G1F and G2F of the validation set
RG0F=Pd*100;
RG1F=Pg*100;
RG2F=Ph*100;













