function [Se] = fSe(wA2,wC1,wC2,wE1)
global conA2;
global FA2;
global PA2

Se=PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo2(fcon(ffFC2(wA2,wC1)),wC2).*sigmo1(fcon(ffFE1(wA2,wC1,wC2)),wE1);


end