function [FE2] = fFE2(wA2,wC1,wC2,conC1,conC2,conE1,wE1)
global conA2;
global FA2;

FE2=FA2.*sigmo1(conA2,wA2).*sigmo2(conC1,wC1).*sigmo2(conC2,wC2).*sigmo2(conE1,wE1);

end
