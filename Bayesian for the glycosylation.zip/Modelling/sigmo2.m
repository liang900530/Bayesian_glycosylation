%sigmoid function

function [y] = sigmo2(x,w)

y=1-(1./(1+exp(x*w.*(-1))));

end

