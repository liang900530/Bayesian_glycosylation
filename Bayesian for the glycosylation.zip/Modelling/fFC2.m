function [FC2] = fFC2(wA2,wC1,conC1)
global conA2;
global FA2;

FC2=FA2.*sigmo1(conA2,wA2).*sigmo2(conC1,wC1);


end
