function E = wHM2(w)
global con
global FA
 y=abs(sigmo1(con,w')-FA);
E=sum(y);
end
