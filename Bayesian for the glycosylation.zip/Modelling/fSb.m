function [Sb] = fSb(wA2,wC1,wC2,wB)
global conA2;
global FA2;
global PA2


Sb=(PA2.*sigmo2(conA2,wA2)+PA2.*sigmo1(conA2,wA2).*sigmo2(fcon(fFC1(wA2)),wC1).*sigmo1(fcon(ffFC2(wA2,wC1)),wC2)).*sigmo1(fcon(ffFB(wA2,wC1,wC2)),wB);

end