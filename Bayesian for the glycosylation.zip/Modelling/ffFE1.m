function [FE1] = ffFE1(wA2,wC1,wC2)
global conA2;
global FA2;

FE1=fFE1(wA2,wC1,wC2,fcon(fFC1(wA2)),fcon(fFC2(wA2,wC1,fcon(fFC1(wA2)))));


end