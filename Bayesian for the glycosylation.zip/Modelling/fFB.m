function [FB] = fFB(wA2,wC1,wC2,conC1,conC2)
global conA2;
global FA2;

FB=FA2.*sigmo2(conA2,wA2)+FA2.*sigmo1(conA2,wA2).*sigmo2(conC1,wC1).*sigmo1(conC2,wC2);


end
