% Probabilistic graphic model, for perfusion
% Liang Zhang KTH  2019-04
%% read data
clear all
clc
load('data_perfusion');
CD=data(:,1);
PR=data(:,2);
CSPR=data(:,3);
Cglc=data(:,4);
Clac=data(:,5);
Camm=data(:,6);
CmAb=data(:,7);
mu=data(:,8);
qIgG=data(:,9);
qGlc=data(:,10);
input=data(:,1:10);
Gly=data(:,11); %percentage of galactosylation

% PCA
[coeff,score,latent] =pca(input);
 
Modelinput=score(:,1:2);
Modelinput(31:34,:)=[];

%%

global Man % the first input
global Gal % the second input
Man=Modelinput(:,1);  
Gal=Modelinput(:,2);  
load('IgG_perfusion')
IgG(31:34,:)=[]; 
con=[Man,Gal,IgG,ones(46,1)];% the culture condition

%% The glycans data from experiment
global FA2;
global PA2;
global PGly;
load('PGly_perfusion')
PGly(31:34,:)=[];
PGly=PGly./100;
FGly=PGly.*IgG;
FA=FGly(:,1); Fb=FGly(:,2); Fc=FGly(:,3); Fd=FGly(:,4); %flux
Fe=FGly(:,5); Ff=FGly(:,6); Fg=FGly(:,7); Fh=FGly(:,8); Fun=FGly(:,9);
PA=PGly(:,1); Pb=PGly(:,2); Pc=PGly(:,3); Pd=PGly(:,4); %percentage
Pe=PGly(:,5); Pf=PGly(:,6); Pg=PGly(:,7); Ph=PGly(:,8); Pun=PGly(:,9);
FG=Fg+Fh; PG=Pg+Ph;
FA2=IgG-FA-Fun; PA2=1-PA-Pun;
data=[Man,Gal,FGly];
R=[Pc,Pb,Pe,Pd,Pf,PG,Ph].*100;

%% lsqnonlin for HM

w=wHM(con,PA);
WHM=[w(1);w(2);w(3);w(4)];
yHM=sigmo1(con,WHM);
EHM=abs(PA-yHM)./PA.*100;
s1HM=sum(EHM)
s2HM=max(EHM)

%% G for G2F and G1F
conG2F=[Man,Gal,FG,ones(46,1)];
PFh=Ph./PG;
w=wHM(conG2F,PFh);
WG=[w(1);w(2);w(3);w(4)];
yh=sigmo1(conG2F,WG); % predicted the percentage of h in G
PPh=PG.*yh;  % predicted, percentage of h
Eh=abs(Ph-PPh)./Ph.*100;
Eah=abs(Ph-yh).*100;
s1h=sum(Eh)
s2h=max(Eh)
a=yh.*PG;

%% Parameter Identification
global conA2;
conA2=[Man,Gal,FA2,ones(46,1)];
global cons
cons=46;
w=Optim_P(PGly)
    

%% Validation

Modelinput=score(:,1:2);
Man=Modelinput(:,1);  
Gal=Modelinput(:,2);  
load('IgG_perfusion');
con=[Man,Gal,IgG,ones(50,1)];

load('PGly_perfusion');
PGly=PGly./100;
FGly=PGly.*IgG;
FA=FGly(:,1); Fb=FGly(:,2); Fc=FGly(:,3); Fd=FGly(:,4); %flux
Fe=FGly(:,5); Ff=FGly(:,6); Fg=FGly(:,7); Fh=FGly(:,8); Fun=FGly(:,9);
PA=PGly(:,1); Pb=PGly(:,2); Pc=PGly(:,3); Pd=PGly(:,4); %percentage
Pe=PGly(:,5); Pf=PGly(:,6); Pg=PGly(:,7); Ph=PGly(:,8); Pun=PGly(:,9);
FG=Fg+Fh; PG=Pg+Ph;
FA2=IgG-FA-Fun; PA2=1-PA-Pun;
data=[Man,Gal,FGly];
R=[Pc,Pb,Pe,Pd,Pf,PG,Ph].*100;

cons=50;
    
con=[Man,Gal,IgG,ones(50,1)];
load('PGly_perfusion'); PGly=PGly./100;
FGly=PGly.*IgG;
FA=FGly(:,1); Fb=FGly(:,2); Fc=FGly(:,3); Fd=FGly(:,4);
Fe=FGly(:,5); Ff=FGly(:,6); Fg=FGly(:,7); Fh=FGly(:,8); Fun=FGly(:,9);
PA=PGly(:,1); Pb=PGly(:,2); Pc=PGly(:,3); Pd=PGly(:,4);
Pe=PGly(:,5); Pf=PGly(:,6); Pg=PGly(:,7); Ph=PGly(:,8); Pun=PGly(:,9);
FG=Fg+Fh; PG=Pg+Ph;
FA2=IgG-FA-Fun; PA2=1-PA-Pun;
data=[Man,Gal,FGly];
R=[Pc,Pb,Pe,Pd,Pf,PG,Ph].*100;
conA2=[Man,Gal,FA2,ones(50,1)];
yHM=sigmo1(con,WHM)*100;

wA2=w(1:4)'; wC1=w(5:8)'; wC2=w(9:12)'; wE1=w(13:16)'; wE2=w(17:20)'; wB=w(21:24)'; wD=w(25:28)'; wF=w(29:32)'; 

Sc=fSc(wA2,wC1);
Sb=fSb(wA2,wC1,wC2,wB);
Se=fSe(wA2,wC1,wC2,wE1);
Sd=fSd(wA2,wC1,wC2,wE1,wE2,wB,wD);
Sf=fSf(wA2,wC1,wC2,wE1,wE2,wF);
SG=fSG(wA2,wC1,wC2,wE1,wE2,wB,wD,wF);
conG2F=[Man,Gal,FG,ones(50,1)];
yh=sigmo1(conG2F,WG);
Sh=SG.*yh.*100;
Sg=SG.*100-Sh;
S=[Sc,Sb,Sd,Se,Sf,SG].*100;

%absolute error
Eac=abs(Sc-Pc).*100;
Eab=abs(Sb-Pb).*100;
Eae=abs(Se-Pe).*100;
Ead=abs(Sd-Pd).*100;
Eaf=abs(Sf-Pf).*100;
EaG=abs(SG-PG).*100;
Ea=[Eac(31:34,:),Eab(31:34,:),Ead(31:34,:),Eae(31:34,:),Eaf(31:34,:),EaG(31:34,:)];
EEa=sum(sum(Ea))

S=[Sc,Sb,Sd,Se,Sf,SG].*100;

conG2F=[Man,Gal,FG,ones(50,1)];
PFh=Ph./PG;
yh=sigmo1(conG2F,WG); % predicted   the percentage of h in G
PPh=SG*100.*yh;  % predicted, percentage of h
PPg=SG*100-PPh;

FC1=FA2.*sigmo1(conA2,wA2);
FC2=ffFC2(wA2,wC1);
FB=ffFB(wA2,wC1,wC2);
FE1=ffFE1(wA2,wC1,wC2);
FE2=ffFE2(wA2,wC1,wC2,wE1);
FF=ffFF(wA2,wC1,wC2,wE1,wE2);
FD=ffFD(wA2,wC1,wC2,wE1,wE2,wB);

%The predicted G0F, G1F and G2F of the validation set
G0F=S(:,3);
G1F=PPg*100;
G2F=PPh*100;

% The experimental data of G0F, G1F and G2F of the validation set
RG0F=Pd*100;
RG1F=Pg*100;
RG2F=Ph*100;

%% Flux

Flux=mean([[FC1(31:34),FC2(31:34),FB(31:34),FE1(31:34),FE2(31:34),FF(31:34),FD(31:34)]./qIgG(31:34)*100,S(31:34,:)])

f1=100;
f0=mean(FA2(31:34)./qIgG(31:34)*100);
f2=100-f0;
f4=Flux(1);
f3=f0-f4;
f5=0;
f6=f3;
f9=Flux(8);
f8=Flux(4);
f14=Flux(11);
f7=Flux(3)-f3;
f10=Flux(9);
f11=Flux(3)-f10;
f12=Flux(7)-f11;
f15=Flux(10);
f13=Flux(6);
f18=Flux(12);
f17=f13-f18;
f16=Flux(7)-f15;
f20=mean(PPh(31:34));
f19=Flux(13)-f20;

% The glycosylation fluxes of the validation culture condition
f=[f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f14,f15,f16,f17,f18,f19,f20];

